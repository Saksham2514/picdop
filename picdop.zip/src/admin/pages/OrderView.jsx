import {
  Grid,
  InputAdornment,
  Button,
  TextField,
  Typography,
} from "@material-ui/core";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import NestedModal from "./Modal";
import { useEffect } from "react";
import axios from "axios";

const ParcelForm = ({ id }) => {
  const [data, setData] = React.useState([]);

  const [fileArray, setFA] = useState(["https://source.unsplash.com/300x300"]);

  useEffect(() => {
    // alert("invoked");
    axios
      .get(`${process.env.REACT_APP_BACKEND_URL}orders/${id}`)
      .then((res) => { 
        setData(res.data);
        console.log(res.data);
        console.log(data);
      }) 
      .catch((err) => console.log(err));
    }, []);
    
  return (
    <div>
      <Typography
        style={{ paddingBottom: "1rem", fontWeight: "bold" }}
        variant="h6"
      >
        Order View
      </Typography>
      <Grid container fullWidth spacing={3}>
        <Grid item xs={12} md={6}>
          <TextField
            size="small"
            fullWidth
            InputProps={{
              readOnly: true,
            }}
            label="From Email"
            // value={data[0]['from']}
            variant="outlined"
            id="outlined-start-adornment"
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            InputProps={{
              readOnly: true,
            }}
            size="small"
            fullWidth
            label="To Email"
            // value={data[0]['to']}
            variant="outlined"
            id="outlined-start-adornment"
          />
        </Grid>
        {/* LBH ROW */}

        <Grid item xs={12}>
          <Typography style={{ fontWeight: "bold" }} variant="h6">
            Parcel Information
          </Typography>
        </Grid>
        <Grid item xs={12} md={3}>
          <TextField
            size="small"
            fullWidth
            label="Weight"
            // value={data[0]['parcelWeight']}
            variant="outlined"
            id="outlined-start-adornment"
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="start">kg</InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <TextField
            size="small"
            fullWidth
            label="Length"
            // value={data[0]['parcelLength']}
            variant="outlined"
            id="outlined-start-adornment"
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="start">inch</InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <TextField
            size="small"
            fullWidth
            label="Width"
            // value={data[0]['parcelWidth']}
            variant="outlined"
            id="outlined-start-adornment"
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="start">inch</InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <TextField
            size="small"
            fullWidth
            label="Height"
            // value={data[0]['parcelHeight']}
            variant="outlined"
            id="outlined-start-adornment"
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="start">inch</InputAdornment>
              ),
            }}
          />
        </Grid>
        {/* LBH ROW ends  */}
        {/* Descritpion and payments mode  */}
        <Grid item xs={12} md={6}>
          <TextField
            id="filled-multiline-flexible"
            label="Description"
            InputProps={{
              readOnly: true,
            }}
            fullWidth
            // value={data[0]["parcelDescription"]}
            variant="outlined"
          />
        </Grid>
        <Grid item xs={12} md={6}></Grid>
        {/* Descritpion and payments mode ends */}
        <Grid item xs={12} md={6}>
          {(fileArray || []).map((url) => (
            <>
              <img
                src={url}
                alt="..."
                height={100}
                width={100}
                style={{ border: "1px solid black" }}
              />
              <br />
            </>
          ))}
        </Grid>
        <Grid item xs={12} md={6}>
          {(fileArray || []).map((url) => (
            <>
              <img
                src={url}
                alt="..."
                height={100}
                width={100}
                style={{ border: "1px solid black" }}
              />
              <br />
            </>
          ))}
        </Grid>
        <Grid item xs={12} md={8}>
          <Link
            to="/collection"
            style={{ textDecoration: "none", borderRadius: "1rem" }}
          >
            <Button
              style={{ backgroundColor: "var(--main-color)", color: "white" }}
            >
              Back To Dashboard
            </Button>
          </Link>
          <Button
            variant="contained"
            size="small"
            style={{
              borderRadius: "0.25rem",
              color: "white",
              backgroundColor: "var(--success-color)",
              margin: "1rem 0.25rem",
              paddingX: "1rem",
              textTransform: "capitalize",
            }}
          >
            Regenerating OTP
          </Button>
        </Grid>
        <Grid xs={12} md={3} style={{ paddingTop: "0.5rem" }}>
          <NestedModal label="Delete Order">
            <h3 style={{ textAlign: "center" }} id="parent-modal-description">
              Are Your Sure?
            </h3>
            <h3 style={{ textAlign: "center" }} id="parent-modal-description">
              This order will be deleted
            </h3>
          </NestedModal>
        </Grid>
      </Grid>
    </div>
  );
};

export default ParcelForm;
